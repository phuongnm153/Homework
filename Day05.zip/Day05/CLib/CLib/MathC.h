//
//  MathC.h
//  CLib
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#ifndef CLib_MathC_h
#define CLib_MathC_h

float AdditionC (float a,float b);
float SubtractionC (float a,float b);
float MultiplicationC (float a,float b);
float DivisionC (float a,float b);
float SquareC (float a,float b);
float SquarerootC (float a,float b);

#endif
