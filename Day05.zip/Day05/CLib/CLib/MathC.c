//
//  MathC.c
//  CLib
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#include <stdio.h>
float AdditionC (float a,float b){
    return a + b;
}
float SubtractionC (float a,float b){
    return a - b;
}
float MultiplicationC (float a,float b){
    return a * b;
}
float DivisionC (float a,float b){
    return a / b;
}
float SquareC (float a,float b){
    return a*a;
}
float SquarerootC (float a,float b){
    return sqrt(a);
}
