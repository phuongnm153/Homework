//
//  ViewController.m
//  MainProject
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#import "ViewController.h"
#include <MathC.h>
#include <MathOC.h>
@interface ViewController ()

@end

@implementation ViewController
@synthesize rdbOC,rdbC,lblSolution,inta,intb;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}
-(void)viewDidAppear:(BOOL)animated{
  
    
    //radio buttons
    rdbOC = [[UIButton alloc] initWithFrame:CGRectMake(40, 155, 25, 25)];
    [rdbOC setTag:0];
    [rdbOC setBackgroundImage:[UIImage imageNamed:@"RBOff.png"] forState:UIControlStateNormal];
    [rdbOC setBackgroundImage:[UIImage imageNamed:@"RBOn.png"] forState:UIControlStateSelected];
    [rdbOC addTarget:self action:@selector(radiobuttonSelected:) forControlEvents:UIControlEventTouchUpInside];
    
    rdbC = [[UIButton alloc] initWithFrame:CGRectMake(180, 155, 25, 25)];
    [rdbC setTag:1];
    [rdbC setBackgroundImage:[UIImage imageNamed:@"RBOff.png"] forState:UIControlStateNormal];
    [rdbC setBackgroundImage:[UIImage imageNamed:@"RBOn.png"] forState:UIControlStateSelected];
    [rdbC addTarget:self action:@selector(radiobuttonSelected:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view addSubview:rdbOC];
    [self.view addSubview:rdbC];
}
-(void)radiobuttonSelected:(id)sender{
    switch ([sender tag]) {
        case 0:
            if([rdbOC isSelected]==YES)
            {
                [rdbOC setSelected:NO];
                [rdbC setSelected:YES];
            }
            else{
                [rdbOC setSelected:YES];
                [rdbC setSelected:NO];
            }
            
            break;
        case 1:
            if([rdbC isSelected]==YES)
            {
                [rdbC setSelected:NO];
                [rdbOC setSelected:YES];
            }
            else{
                [rdbC setSelected:YES];
                [rdbOC setSelected:NO];
            }
            
            break;
        default:
            break;
    }
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)Add:(id)sender {
    float fla = [inta.text floatValue];
    float flb = [intb.text floatValue];
    if([rdbOC isSelected]==YES)
    {
        MathOC *add = [[MathOC alloc] init];
        lblSolution.text = [NSString stringWithFormat:@"Object C :%10.1f",[add Add:fla andb:flb]];
    }
    else{
        lblSolution.text = [NSString stringWithFormat:@"C :%10.1f",AdditionC(fla, flb)];
    }
}
- (IBAction)Sub:(id)sender {
    float fla = [inta.text floatValue];
    float flb = [intb.text floatValue];
    if([rdbOC isSelected]==YES)
    {
        MathOC *add = [[MathOC alloc] init];
        lblSolution.text = [NSString stringWithFormat:@"Object C :%10.1f",[add Sub: fla andb:flb]];
    }
    else{
        lblSolution.text = [NSString stringWithFormat:@"C :%10.1f",SubtractionC(fla, flb)];
    }
}
- (IBAction)Multi:(id)sender {
    float fla = [inta.text floatValue];
    float flb = [intb.text floatValue];
    if([rdbOC isSelected]==YES)
    {
        MathOC *add = [[MathOC alloc] init];
        lblSolution.text = [NSString stringWithFormat:@"Object C :%10.1f",[add Muti:fla andb:flb]];
    }
    else{
        lblSolution.text = [NSString stringWithFormat:@"C :%10.1f",MultiplicationC(fla, flb)];
    }
}
- (IBAction)Divi:(id)sender {
    float fla = [inta.text floatValue];
    float flb = [intb.text floatValue];
    if([rdbOC isSelected]==YES)
    {
        MathOC *add = [[MathOC alloc] init];
        lblSolution.text = [NSString stringWithFormat:@"Object C :%10.1f",[add Div:fla andb:flb]];
    }
    else{
        lblSolution.text = [NSString stringWithFormat:@"C :%10.1f",DivisionC(fla, flb)];
    }
}
- (IBAction)SQR:(id)sender {
    float fla = [inta.text floatValue];
    float flb = [intb.text floatValue];
    if([rdbOC isSelected]==YES)
    {
        MathOC *add = [[MathOC alloc] init];
        lblSolution.text = [NSString stringWithFormat:@"Object C :%10.1f",[add Sqr:fla andb:flb]];
    }
    else{
        lblSolution.text = [NSString stringWithFormat:@"C :%10.1f",SquareC(fla, flb)];
    }
}
- (IBAction)SQRT:(id)sender {
    float fla = [inta.text floatValue];
    float flb = [intb.text floatValue];
    if([rdbOC isSelected]==YES)
    {
        MathOC *add = [[MathOC alloc] init];
        lblSolution.text = [NSString stringWithFormat:@"Object C :%10.1f",[add Sqrt:fla andb:flb]];
    }
    else{
        lblSolution.text = [NSString stringWithFormat:@"C :%10.1f",SquarerootC(fla, flb)];
    }
}

@end
