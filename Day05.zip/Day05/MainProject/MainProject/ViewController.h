//
//  ViewController.h
//  MainProject
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *rdbOC;
@property (strong, nonatomic) IBOutlet UIButton *rdbC;
@property (strong, nonatomic) IBOutlet UILabel *lblSolution;
@property (weak, nonatomic) IBOutlet UITextField *inta;
@property (weak, nonatomic) IBOutlet UITextField *intb;
-(void)radiobuttonSelected:(id)sender;
@end
