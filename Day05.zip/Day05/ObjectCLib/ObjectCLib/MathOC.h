//
//  MathOC.h
//  ObjectCLib
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MathOC : NSObject
-(float) Add :(float) a andb:(float) b;
-(float) Sub :(float) a andb:(float) b;
-(float) Muti :(float) a andb:(float) b;
-(float) Div :(float) a andb:(float) b;
-(float) Sqr :(float) a andb:(float) b;
-(float) Sqrt :(float) a andb:(float) b;
@end
