//
//  MathOC.m
//  ObjectCLib
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#import "MathOC.h"

@implementation MathOC
-(float) Add :(float) a andb:(float) b{
    return a+b;
}
-(float) Sub :(float) a andb:(float) b{
    return a-b;
}
-(float) Muti :(float) a andb:(float) b{
    return a*b;
}
-(float) Div :(float) a andb:(float) b;{
    return a/b;
}
-(float) Sqr :(float) a andb:(float) b;{
    return a*a;
}
-(float) Sqrt :(float) a andb:(float) b{
    return sqrt(a);
}
@end
