//
//  ObjectCLib.m
//  ObjectCLib
//
//  Created by MAC on 10/14/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#import "ObjectCLib.h"

@implementation ObjectCLib

@end
